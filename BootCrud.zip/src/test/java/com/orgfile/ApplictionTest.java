package com.orgfile;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ApplictionTest {

}
