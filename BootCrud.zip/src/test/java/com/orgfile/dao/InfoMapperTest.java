package com.orgfile.dao;

import com.orgfile.ApplictionTest;
import com.orgfile.controller.FileUploadController;
import com.orgfile.entity.Info;
import com.orgfile.entity.Picture;
import com.orgfile.entity.User;
import com.orgfile.service.InfoService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.ResourceUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class InfoMapperTest extends ApplictionTest {


    @Autowired
    private InfoMapper infoMapper;

    @Autowired
    private InfoService infoService;


    @Test
    void selectAll() {
         Integer result = infoMapper.createInfo(new Info("大大大所多","大大声多所"));
         if(result > 0){
             for (Info i:infoMapper.selectAll()){
                 System.out.println(i);
             }
         }
//        for (Info i:infos){
//            System.out.println(i.toString());
//        }
    }

    @Test
    public void test1(){
        Map<String,Integer> map = new HashMap<>();
        map.put("id",136);
        Info info = infoMapper.selectList(map);
        System.out.println(info);
    }


    @Autowired
    private UserMapper userMapper;


    @Test
    public void test7(){
        User u = new User();
        u.setUsername("dads");
        u.setPassword("123");
        u.setAge(21);
        u.setSex(0);
        u.setPhone("1234564");
        u.setCreatedate(new Date());
        int count = userMapper.userAdd(u);
        System.out.println(count>0);

    }


    @Value("${file.path}")
    private String path;

    @Test
    public void test(){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String format = sdf.format(new Date());
        System.out.println(format);
//        String filepath = path+"ds";
//        System.out.println(filepath);
    }

    @Test
    public void test8(){
//        MultipartFile file = null;
//        //获取文件的类型 例如 XX.jpg
//        String exName = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
//
//
//        //获取文件名称 是什么
//        String fileName = UUID.randomUUID().toString()+exName;
//
//
//
//        //填写路径，将文件上传在盘符路径上
//        FileCopyUtils.copy(file.getInputStream(),new FileOutputStream(new File(fileName)));
    }


    @Autowired
    private PictureMapper pictureMapper;

    @Test
    public void test9() throws FileNotFoundException {
        Picture p = new Picture();
        p.setId(16);
        Picture picture = pictureMapper.getByid(p);
        System.out.println(picture.getPath());

        //获取项目名称地址
//        String realpath = ResourceUtils.getURL("classpath:").getPath()+"/"+picture.getPath();
//        System.out.println(realpath);
        //获取到路径删除
        File file = new File(picture.getPath());
        //判断是否有文件存在
        if(file.exists()){
            //有文件就立即删除
            file.delete();
            System.out.println("删除");
        }

        pictureMapper.deleteAll(p.getId());
        System.out.println("成功删除");
    }


    @Test
    public void test10(){
        //获取文件地址以及文件名 删除
        String path = "F:\\path\\1b491f47f6abf93cf072de4ead.jpg";
        System.out.println(path);

        //将路径和文件名拆分开入参 删除
//        File file = new File("F:\\path","0c927e4aba902c03105560e1c5.jpg");
        File file = new File(path);
        if(file.exists()){
            file.delete();
            System.out.println("删除");
        }


    }

    @Test
    public void test11(){

//        List<Integer> integers = Arrays.asList(1,2,3,4,5,6,7,8,9,11,12,13,14,15);
        Integer[] integers = new  Integer[]{18,
                19,
                21,
                22,
                23,
                24,
                25,
                26,
                27
        };
        int count = pictureMapper.deletePics(integers);
        System.out.println(count>0);
    }
    

}