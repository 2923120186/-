package com.orgfile.dao;

import com.orgfile.Application;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class FileTest extends Application {


    /*文件操作补充
    https://www.cnblogs.com/lingyejun/p/9744509.html
     */

    public static final String READ_UTF8_FILE_PATH = "F:\\path";
    @Test
    public void test1() throws IOException {
        File file = new File(READ_UTF8_FILE_PATH);
        InputStream is = new FileInputStream(file);
        //字节数组
        byte[] bytes = new byte[1024];

        //每次读取字节数
        int readLength;

        while ((readLength = is.read(bytes)) != -1) {
            // UTF-8为变长编码，一个汉字占3个字节
            System.out.println("本次读取" + readLength + "个字节数据内容为:" + new String(bytes));
        }
        is.close();
    }

}
