package com.orgfile.controller;

import com.orgfile.common.Constants;
import com.orgfile.common.Result;
import com.orgfile.common.ResultGenerator;
import com.orgfile.dao.PictureMapper;
import com.orgfile.entity.Picture;
import com.orgfile.service.PictureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

@RestController
public class FileUploadController {

    /* 上传相关的细节
      https://blog.csdn.net/qq_37939251/article/details/82975495
     https://blog.csdn.net/CSDN_java1005/article/details/106619648
     https://blog.csdn.net/dingyufei615/article/details/95496788
     https://blog.csdn.net/java_miss_you/article/details/104400320?utm_medium=distribute.pc_relevant_t0.none-task-blog-BlogCommendFromMachineLearnPai2-1.control&depth_1-utm_source=distribute.pc_relevant_t0.none-task-blog-BlogCommendFromMachineLearnPai2-1.control
     https://blog.csdn.net/qq_36595528/article/details/88806885
     https://www.cnblogs.com/xiaowangxiao/p/10936537.html

     */


    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    @PostMapping(value = "/upload1")
    public String upload1(MultipartFile file, HttpServletRequest request){

        //定义现在日期格式化
        String format = sdf.format(new Date());

        //定义文件目录
        String path = request.getServletContext().getRealPath("/img")+format;
        File folder = new File(path);
        if(!folder.exists()){
            folder.mkdirs();
        }

        //获取文件信息
        String oldName = file.getOriginalFilename();
        String newName = UUID.randomUUID().toString()+oldName.substring(oldName.lastIndexOf("."));

        try {
            file.transferTo(new File(folder,newName));
            String url = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + "/img" + format + newName;
            return url;
        }catch (IOException e){
            e.printStackTrace();
        }

        return "error";
    }

    @Value("${file.path}")
    private String filepath;

    @Autowired
    private PictureMapper pictureMapper;

    /*
    图片上传的第一种方法
     */
    @PostMapping(value = "/upload2")
    public Result upload2(@RequestParam("filePic") MultipartFile filePic) throws IOException{

        /*if(filePic == null){
            return ResultGenerator.genErrorResult(Constants.RESULT_CODE_PARAM_ERROR,"上传文件不能为空");
        }*/

        //获取文件的类型 例如xx.jpg .jpg这个文件的后缀格式是什么 获取文件后缀
        String suffixName = filePic.getOriginalFilename().substring(filePic.getOriginalFilename().lastIndexOf("."));
        System.out.println(suffixName);


        //以日期的方式自定义文件新名称
        //String newName = sdf.format(new Date());


        System.out.print(filepath);

        //获取文件名称 更文件名称
        String fileName = UUID.randomUUID().toString().replace("-","").substring(6)+suffixName;
        System.out.println(fileName);

        //拼接路径文件新名称和后缀
        //String path = filepath+fileName+suffixName;
        String path = filepath+fileName;

        //填写路径，将文件上传在盘符路径上 另外copy就是把已存在的文件给覆盖上
        FileCopyUtils.copy(filePic.getInputStream(),new FileOutputStream(new File(path)));

        Picture p = new Picture();
        p.setPath(filepath);
        p.setFileName(fileName);
        int count = pictureMapper.addPath(p);
        if(count>0){
            return ResultGenerator.genResultSuccess("上传成功"+fileName);
        }else{
            return ResultGenerator.genFailResult("上传失败");
        }
    }


    /*
    上传的第二种方法
     */
    @PostMapping(value = "/saveIng1")
    public Result saveIng1(@RequestParam("filePic") MultipartFile filePic) throws IOException{
        String picName = sdf.format(new Date());
        final String pathName = "f:\\imagePath\\"+picName+".jpg";

        System.out.println(pathName);

        Picture p = new Picture();
        if(!filePic.isEmpty()){

            BufferedOutputStream out = new BufferedOutputStream(
                    new FileOutputStream(
                            new File(pathName)));//保存图片在该目录里

            out.write(filePic.getBytes());
            out.flush();
            out.close();
            String path = pathName;

            p.setPath(path);

            int count = pictureMapper.addPath(p);
            if(count > 0){
                return ResultGenerator.genResultSuccess();
            }
        }
        return ResultGenerator.genFailResult("上传失败");
    }


    @Autowired
    @Resource(name = "pictureService")
    private PictureService pictureService;

    @GetMapping(value = "/showAll")
    public Result showAll(){
        Result result = new Result();
        List<Picture> pictures = pictureService.queryFiles();
        if(StringUtils.isEmpty(pictures)){
            result = ResultGenerator.genErrorResult(Constants.RESULT_CODE_SERVER_ERROR,"服务器错误");
            return result;
        }
        result = ResultGenerator.genResultSuccess(pictures);
        return result;
    }

    @PostMapping(value = "/delAll")
    public Result delAll(@RequestBody Picture p ) throws IOException{

        System.out.println(StringUtils.isEmpty(p.getId()) && StringUtils.isEmpty(p.getPath()));

        if(StringUtils.isEmpty(p.getId()) && StringUtils.isEmpty(p.getPath())){
            return ResultGenerator.genErrorResult(Constants.RESULT_CODE_PARAM_ERROR,"参数错误");
        }

        System.out.println(p.getFileName());
        //删除指定文件
        File file = new File(filepath,p.getFileName());
        if(file.exists()){
            file.delete();
            System.out.println("已删除");
        }
        int count = pictureMapper.deleteAll(p.getId());
        if(count>0){
            return ResultGenerator.genResultSuccess();
        }else{
            return ResultGenerator.genFailResult("删除失败");
        }
    }

    /*
    http://www.cppcns.com/ruanjian/java/237756.html

    https://blog.csdn.net/qq_38762237/article/details/81283241
    https://blog.csdn.net/qq_38762237/article/details/81282444
     */

    @GetMapping(value = "/showFile")
    public Result showFile(@RequestParam("id") Integer id) throws IOException{

        Picture p = pictureService.findByid(id);

//        String dad =Constants.FILE_PRE_URL;

        String filepath = Constants.FILE_PRE_URL+"images/"+p.getFileName();
        System.out.println(filepath);
        p.setPath(filepath);
        return ResultGenerator.genResultSuccess(p);
    }


}
