package com.orgfile.controller;

import com.orgfile.entity.Info;
import com.orgfile.service.InfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/*
@RestController在使用时可以不标记@ResponseBody
以为@RestController为每一个方法都加上了@ResponseBody
 */
@RestController
@RequestMapping("/info")
public class InfoController {


    @Autowired
    @Qualifier("infoService")
    private InfoService infoService;

    @GetMapping(value = "/showlist")
    public List<Info> showlist(){
        List<Info> infos = infoService.selectAll();
        return infos;
    }


    @RequestMapping(value="/showByname",method = RequestMethod.POST)
    public List<Info> showByname(@RequestBody String name){
        System.out.println(name);
        System.out.println("++++++++++++");
        List<Info> infos = infoService.selectByName(name);
        return infos;
    }

    @RequestMapping(value = "/adds",method = RequestMethod.POST)
    public void add(Info i){
        if(StringUtils.isEmpty(i.getName()) || StringUtils.isEmpty(i.getMyinfo())){
            System.out.println("没输入");
        }
        System.out.println(i.getName()+"======"+i.getMyinfo());
        infoService.createInfo(i.getName(),i.getMyinfo());
    }

    @RequestMapping(value = "/showdel",method = RequestMethod.POST)
    public void showdel(@RequestParam("id") Integer id){
        if(StringUtils.isEmpty(id)){
            System.out.println("无操作");
        }
        System.out.println(id);
        int result = infoService.delByid(id);
        if(result>0){
            System.out.println("删除成功");
        }
    }

    /*  分页补充
        https://www.pianshen.com/article/1526422588/
        https://blog.csdn.net/weixin_41866607/article/details/104256503
     */

    @RequestMapping(value = "showLimit")
    public void showLimit(){

    }

}
