package com.orgfile.controller;

import com.orgfile.common.Constants;
import com.orgfile.common.Result;
import com.orgfile.common.ResultGenerator;
import com.orgfile.dao.UserMapper;
import com.orgfile.entity.User;
import com.orgfile.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserMapper userMapper;

    @GetMapping(value = "/show")
    public Result show(){
        List<User> users = userMapper.findAllUsers();
        if(StringUtils.isEmpty(users)){
            return ResultGenerator.genErrorResult(Constants.RESULT_CODE_PARAM_ERROR,"参数错误");
        }
        return ResultGenerator.genResultSuccess(users);
    }

    @Autowired
    @Qualifier("userService")
    private UserService userService;

    @PostMapping(value = "/userAdd")
    public Result userAdd(@RequestBody User u){
        if(StringUtils.isEmpty(u)){
            return ResultGenerator.genErrorResult(Constants.RESULT_CODE_PARAM_ERROR,"参数错误");
        }
        u.setCreatedate(new Date());
        int result = userService.createUsers(u);
        if(result > 0) {
            return ResultGenerator.genResultSuccess();
        }else {
            return ResultGenerator.genFailResult("注册失败");
        }
    }


    @PostMapping(value ="/getUser")
    public User  getUser(@RequestBody User u){
        System.out.println(u.toString());
        return u;
    }



}
