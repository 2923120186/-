package com.orgfile.controller;

import com.alibaba.druid.support.json.JSONUtils;
import com.orgfile.common.Constants;
import com.orgfile.common.Result;
import com.orgfile.common.ResultGenerator;
import com.orgfile.dao.InfoMapper;
import com.orgfile.entity.Info;
import com.orgfile.service.InfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/is")
public class IsController {

    @Autowired
    @Qualifier("infoService")
    private InfoService infoService;

    @Autowired
    private InfoMapper infoMapper;


    /*
      交互页面 selectAll.html
      查询全部
     */
    @GetMapping(value = "/selectAll")
    public Result selectAll(){
        List<Info> infos = infoService.selectAll();
        if(StringUtils.isEmpty(infos) ){
            return ResultGenerator.genErrorResult(Constants.RESULT_CODE_PARAM_ERROR,"参数异常");
        }
        //将查询数据的集合返回给前端
        return ResultGenerator.genResultSuccess(infos);
    }


    @GetMapping(value = "/selectByid")
    public Result selectByid(@RequestParam("id") Integer id){
        Map<String,Integer> map = new HashMap<>();
        map.put("id",id);
        Info infos = infoMapper.selectList(map);
        System.out.println(infos.toString());
        if(infos != null) {
            return ResultGenerator.genResultSuccess(infos);
        }
        return ResultGenerator.genFailResult("接口错误");
    }


    @PostMapping(value = "/upd")
    public Result upd (@RequestBody Info info){
        System.out.println(info.getId());
        if(info.getId() == null ||  StringUtils.isEmpty(info.getName()) || StringUtils.isEmpty(info.getMyinfo())){
            return ResultGenerator.genErrorResult(Constants.RESULT_CODE_PARAM_ERROR,"参数异常");
        }
        int resultCount = infoMapper.update(info);
        System.out.println(resultCount);
        if(resultCount > 0){
            return ResultGenerator.genResultSuccess();
        }else {
            return ResultGenerator.genFailResult("删除失败");
        }
    }

    @PostMapping(value = "/add")
    public Result add(@RequestBody Info i){
        System.out.println(i.getName()+"++++++++++++"+i.getMyinfo());
        if(StringUtils.isEmpty(i.getName()) || StringUtils.isEmpty(i.getMyinfo())){
            return ResultGenerator.genErrorResult(Constants.RESULT_CODE_PARAM_ERROR,"参数异常");
        }
        int resultcode = infoService.createInfo(i.getName(),i.getMyinfo());
        if(resultcode>0){
            return ResultGenerator.genResultSuccess();
        }
        else {
            return ResultGenerator.genFailResult("增加失败");
        }
    }

    @PostMapping(value = "/delete")
    public Result delete(@RequestParam("id") Integer id){
        if(StringUtils.isEmpty(id)){
            return ResultGenerator.genErrorResult(Constants.RESULT_CODE_PARAM_ERROR,"参数异常");
        }
        int resultcount = infoService.delByid(id);
        if(resultcount > 0){
            return ResultGenerator.genResultSuccess();
        }
        else {
            return ResultGenerator.genFailResult("删除失败");
        }
    }








}
