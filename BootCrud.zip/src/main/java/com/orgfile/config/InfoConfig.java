package com.orgfile.config;

import com.orgfile.entity.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class InfoConfig {


    @Bean("infobean")
    public Info showUser(){
        Info info = new Info(12,"王大拿","修理师");
        return info;
    }

}
