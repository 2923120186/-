package com.orgfile.config;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Aspect
@Configuration
public class MyAspect {

    @Pointcut("execution(* com.orgfile.service.impl.*.*(..))")
    public void pc(){ }

    @Before("pc()")
    public void mybefore(JoinPoint i){
        System.out.println("ClassName"+i.getTarget());
        System.out.println("Args"+i.getArgs());
        System.out.println("Method Name"+i.getSignature().getName());
        System.out.println("Mybefore========");
    }

    @AfterReturning(value = "pc()",returning = "ret")//后置通知
    public void myAfterReturning(JoinPoint i,Object ret){
        System.out.println("myAfterReturning"+ret);//返回数据结果是哪些
    }

    @Around("pc()")//环绕通知
    public Object myinterceptor(ProceedingJoinPoint p)throws Throwable{
        System.out.println("myinterceptor1");
        Object o = p.proceed();
        System.out.println("myinterceptor2");
        return o;
    }


    @AfterThrowing(value = "pc()",throwing = "e")//异常通知
    public void myThrows(JoinPoint jp,Exception e){
        System.out.println("Throws");
        System.out.println("========"+e.getMessage());
    }


}
