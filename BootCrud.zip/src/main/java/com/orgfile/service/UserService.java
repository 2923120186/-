package com.orgfile.service;

import com.orgfile.entity.User;

public interface UserService {

    public int createUsers(User u);

}
