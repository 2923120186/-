package com.orgfile.service;

import com.orgfile.entity.Picture;

import java.util.List;

public interface PictureService {


    List<Picture> queryFiles();

    Picture findByid(Integer id);

}
