package com.orgfile.service;

import com.github.pagehelper.PageInfo;
import com.orgfile.entity.Info;

import java.util.List;

public interface InfoService {

    List<Info> selectAll();

    List<Info> selectByName(String name);

    int createInfo(String name ,String myinfo);

    int delByid(Integer id);

    PageInfo<Info> findLimit(Integer pageN, Integer pageS);
}
