package com.orgfile.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.orgfile.dao.InfoMapper;
import com.orgfile.entity.Info;
import com.orgfile.service.InfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("infoService")
public class InfoServiceImpl implements InfoService {


    @Autowired
    private InfoMapper infoMapper;

    @Override
    public List<Info> selectAll() {
        return infoMapper.selectAll();
    }

    @Override
    public List<Info> selectByName(String name) {
        return infoMapper.selectByName(new Info(name));
    }

    @Override
    public int createInfo(String name, String myinfo) {
        return infoMapper.createInfo(new Info(name,myinfo));
    }

    @Override
    public int delByid(Integer id) {
        Map<String,Object> map = new HashMap<>();
        map.put("id",id);
        return infoMapper.delAll(map);
    }

    @Override
    public PageInfo<Info> findLimit(Integer pageN, Integer pageS) {
        if(pageN == null){
            pageN = 1;
        }
        PageHelper.startPage(pageN,pageS);
        List<Info> infos = infoMapper.limitAll();
        PageInfo<Info> pageInfo = new PageInfo<Info>(infos);
        return pageInfo;
    }


}
