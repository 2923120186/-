package com.orgfile.service.impl;

import com.orgfile.dao.UserMapper;
import com.orgfile.entity.User;
import com.orgfile.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("userService")
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public int createUsers(User u) {
        return userMapper.userAdd(u);
    }
}
