package com.orgfile.service.impl;

import com.orgfile.dao.PictureMapper;
import com.orgfile.entity.Picture;
import com.orgfile.service.PictureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("pictureService")
public class PictureServiceImpl implements PictureService {
    @Autowired
    private PictureMapper pictureMapper;

    @Override
    public List<Picture> queryFiles() {
        return pictureMapper.getFileAll();
    }

    @Override
    public Picture findByid(Integer id) {
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("id",id);
        Picture pic = pictureMapper.selectByid(map);
        return pic;
    }

}
