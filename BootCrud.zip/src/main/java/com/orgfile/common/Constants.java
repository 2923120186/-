package com.orgfile.common;

public class Constants {

    //成功处理请求
    public static final int RESULT_CODE_SUCCESS = 200;

    //请求错误
    public static final int RESULT_CODE_BAD_REQUEST = 412;

    //未登录
    public static final int RESULT_CODE_NOT_LOGIN = 402;

    //参数错误
    public static final int RESULT_CODE_PARAM_ERROR = 406;

    //服务器错误
    public static final int RESULT_CODE_SERVER_ERROR = 500;

    //上传文件默认的url前缀，根据部署设置自行换行
    public static final String FILE_PRE_URL = "http://localhost:8030/";

    //上传文件保存地址
    public static final String FILE_UPLOAD_PATH = "/home/project/upload/";

}
