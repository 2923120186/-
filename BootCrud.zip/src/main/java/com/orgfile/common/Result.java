package com.orgfile.common;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class Result<T> implements Serializable {

    private int resultCode;

    private String message;

    private T data;


    public Result(int resultCode, String message){
        this.resultCode = resultCode;
        this.message = message;
    }


    public Result failure(String code){
        System.out.println(code);
        return new Result(500,"服务器错误");
    }


}
