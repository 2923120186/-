package com.orgfile;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.scheduling.annotation.EnableScheduling;

//@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class})
@SpringBootApplication
//@EnableScheduling // 定时执行任务
@MapperScan(basePackages = "com.orgfile.dao")
public class BootcrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(BootcrudApplication.class, args);
    }

}
