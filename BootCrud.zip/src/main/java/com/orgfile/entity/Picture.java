package com.orgfile.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Picture implements Serializable {

    private Integer id;

    private String path;

    private String fileName;



    public Picture (Integer id,String path){
        this.id = id;
        this.path = path;
    }
}
