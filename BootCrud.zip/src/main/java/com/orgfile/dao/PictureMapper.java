package com.orgfile.dao;

import com.orgfile.entity.Picture;

import java.util.List;
import java.util.Map;

public interface PictureMapper {

    int addPath(Picture p);

    Picture getByid(Picture p);

    int deleteAll(Integer id);

    List<Picture> getFileAll();


    int deletePics(Integer[] id);

    Picture selectByid(Map<String,Object> map);

}
