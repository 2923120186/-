package com.orgfile.dao;

import com.orgfile.entity.User;

import java.util.List;

/**
 * @author 13
 * MyBatis 测试
 */
public interface UserMapper {
    /**
     * 返回数据列表
     *
     * @return
     */
    List<User> findAllUsers();

    /**
     * 添加
     *
     * @param U
     * @return
     */
    int userAdd(User U);

    /**
     * 修改
     *
     * @param User
     * @return
     */
//    int updUser(User User);

    /**
     * 删除
     *
     * @param id
     * @return
     */
//    int delUser(Integer id);

}
