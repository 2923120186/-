package com.orgfile.dao;

import com.orgfile.entity.Info;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface InfoMapper {

    List<Info> selectAll();

    int update(Info info);

    List<Info> selectByName(Info i);

    int createInfo(Info i);

    int delAll(Map<String,Object> map);

    Info selectList(Map<String,Integer> map);


    List<Info> limitAll();
}
