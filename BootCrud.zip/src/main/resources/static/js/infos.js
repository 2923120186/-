
//加载数据
$(function () {
    // var tbody = document.getElementById("tbody");
    /*获取获取标签中的值
    var trdata = $("#trdata").val();
     */
    $.ajax({
        type: "get",
        url:"/info/showlist",
        contentType:"application/json;charset=utf-8",
        // data:{},
        dataType:"json",
        success:function (data) {
            $.each(data,function (i,data) {
                $("#tbody").append(
                    "<tr>" +
                    "<td>"+data.id+"</td>"+
                    "<td>"+data.name+"</td>"+
                    "<td>"+data.myinfo+"</td>" +
                    "<td><input id='updbtn' type='button' value='修改' onclick='jump("+data.id+")'/></td>" +
                    "<td><input id='delbtn' type='button' value='删除' onclick='del("+data.id+")'/></td>"+
                    "</tr>"
                )
                // $("#tbody").append("<tr>" +
                //     "<td>"+data.id+"</td>"+
                //     "<td>"+data.name+"</td>"+
                //     "<td>"+data.myinfo+"</td>"+
                //     "</tr>")
            });
        },error:function () {
            window.alert("查询失败");
        }
    });
})


//按id查询相对应的数据来辅助updsub来进行修改
function jump(id) {

// @GetMapping(value = "/selectByid/{id}")
//     public Result selectByid(@PathVariable("id") Integer id){
//         Map<String,Integer> map = new HashMap<>();
//         map.put("id",id);
//         Info infos = infoMapper.selectList(map);
//         System.out.println(infos.toString());
//         return ResultGenerator.genResultSuccess(infos);
//     }

    // $.ajax({
    //     type:"GET",
    //     url: "/is/selectByid/"+id,
    //     contentType: "application/json",
    //     success:function (r) {
    //         if(r.resultCode == 200 && r.data != null){
    //             $("#i-name").val(r.data.name);
    //             $("#i-myinfo").val(r.data.myinfo);
    //             $("#box-from").append("<input id='sub' type='button' onclick='updsub("+r.data.id+")' value='提交'>")
    //         }
    //     },error:function () {
    //         window.alert("检索失败");
    //     }
    // });

    var data = {"id":id}
    $.ajax({
        type:"GET",
        url:"/is/selectByid",
        datatype:"Text",
        data: data,
        success:function (r) {
                    if(r.resultCode == 200 && r.data != null){
                        $("#i-name").val(r.data.name);
                        $("#i-myinfo").val(r.data.myinfo);
                        $("#box-from").append(
                            "<input id='sub' type='button' onclick='updsub("+r.data.id+")' value='提交'>"
                        )
                    }
                    console.log("检索成功");
                    window.alert(r.resultCode);
        },error:function () {
            console.log("检索失败");
        }
    });
}

//修改
function updsub(id){
    var name = $("#i-name").val();
    var myinfo = $("#i-myinfo").val();
    var data = {"id":id,"name":name,"myinfo":myinfo};
    var jsondata = JSON.stringify(data);
    $.ajax({
        type:"post",
        url:"/is/upd",
        data: jsondata,
        contentType:"application/json",
        dataType: "json",
        success:function (r) {
            if(r.resultCode == 200){
                window.alert("修改成功");
            }
            window.location.reload();
        },error:function () {
            window.alert("修改失败");
        }
    });
}


//删除
function del(id) {
    // var data  = {"id":id};
    $.ajax({
        type: "post",
        url: "/info/showdel",
        datatype:"Text",
        data:{"id":id},
        // async:false,
        success:function () {
            alert("删除成功");
            //删除后刷新页面清除遗留的数据
            window.location.reload();
        },
        error:function() {
            alert("删除失败");
        }
    });
}


// function add(){
//     var name = $(".name").val();
//     var myinfo = $(".myinfo").val();
//     var data = {"name":name,"myinfo":myinfo};
//     var jsondata = JSON.stringify(data);
//     $.ajax({
//         type: "post",
//         url:"/is/add",
//         data: jsondata,
//         datatype: JSON,
//         contentType:"application/json",
//         success:function (r) {
//             if(r.resultCode == 200){
//                 window.alert("增加成功");
//             }
//         },error:function () {
//             window.alert("增加失败");
//         }
//     });
// }