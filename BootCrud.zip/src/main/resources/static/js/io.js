
$(function () {
    var picbox = $("#pic-box");
    $.ajax({
        type: "get",
        url: "/showAll",
        dataType:"json",
        success:function (r) {
            if (r.resultCode == 200 && r.data != null){
                $.each(r.data,function (i,data) {
                    picbox.append(
                        "<button onclick=\"delAlls('"+data.id+"','"+data.fileName+"')\">编号"+data.id+"</button>" +
                        "<span><button onclick='showfile("+data.id+")'>查看</button></span><br/>"
                    );
                });
            }
        }
    });
})

function showfile(id) {
    var fbox =  $("#f-box");
    console.log(id);
    $.ajax({
        type:"get",
        url:"/showFile",
        data: {"id":id},
        // contentType:"text",
        // dataType: "json",
        success:function (r) {
            if(r.resultCode == 200 && r.data != null) {
                fbox.empty();
                fbox.append(
                    r.data.id+"<img src='"+r.data.path+"'/>"
                );
            }
        }
    });
}


function delAlls(id,fileName) {
    var data = {"id":id,"fileName":fileName};
    var jsondata = JSON.stringify(data);
    $.ajax({
        type:"post",
        url:"/delAll",
        data:jsondata,
        contentType: "application/json",
        success:function (r) {
            if(r.resultCode == 200){
                window.alert("删除成功");
                location.href ="upload.html";
            }
            if(r.resultCode == 406){
                window.alert("删除失败");
            }
        }
    });
}


function uploadFile(){
    var filename = $("#filename")[0].files[0];
    var filePic = new FormData();
    filePic.append("filePic",filename);
    $.ajax({
        type:"post",
        url:"/upload2",
        processData:false,
        contentType: false,
        data : filePic,
        success:function (r) {
            if(r.resultCode == 200) {
                location.href = "upload.html";
                // $("#result").empty();
                // $("#result").append(r.message);

                return;
            }
            // if(r.resultCode == 406){
            //     $("#result").empty();
            //     $("#result").append(r.message);
            //     return;
            // }
        },
        error:function(r){
            if (r.resultCode == 500){
                $("#result").empty();
                $("#result").append(r.message);
                return;
            }
        }
    });
}