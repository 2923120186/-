
//资料

//获取id选择器里的值
//var name = $("#name").val();

//操作后刷新页面清除遗留的数据
// window.location.reload();

//清空id选择器里的遗留的数据
// $("#con").html('');

//获取获取标签中的值
//var trdata = $("#trdata").val();

//跳转页面 链接有补充 https://www.jianshu.com/p/80f33245b617
//window.location.href = "index.html";
//window.location.href ="/";

//ajax使用 json 传递数据的字符集编码
// contentType:"application/json;charset=utf-8"


/* datatype :“ ”;  补充 https://www.cnblogs.com/learnings/p/7890739.html
预期服务器返回的数据类型。如果不指定，jQuery 将自动根据 HTTP 包 MIME 信息来智能判断，
比如XML MIME类型就被识别为XML。在1.4中，JSON就会生成一个JavaScript对象，而script则会执行这个脚本。
随后服务器端返回的数据会根据这个值解析后，传递给回调函数。可用值:
"xml": 返回 XML 文档，可用 jQuery 处理。
"html": 返回纯文本 HTML 信息；包含的script标签会在插入dom时执行。
"script": 返回纯文本 JavaScript 代码。不会自动缓存结果。除非设置了"cache"参数。'''注意：'''在远程请求时(不在同一个域下)，所有POST请求都将转为GET请求。(因为将使用DOM的script标签来加载)
"json": 返回 JSON 数据 。
"jsonp": JSONP 格式。使用 JSONP 形式调用函数时，如 "myurl?callback=?" jQuery 将自动替换 ? 为正确的函数名，以执行回调函数。
"text": 返回纯文本字符串

contentType细节补充    https://jingyan.baidu.com/article/546ae185d9c9971149f28c3d.html
*/