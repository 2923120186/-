

function createUser() {
    var tab = $(".tab");
    var username = $("#r-username").val();
    var password = $("#r-password").val();
    var pwd = $("#r-pwd").val();
    var age = $("#r-age").val();
    var gender = $('input[name=gender]:checked').val();
    var phone = $("#phone").val();
    if (username == "") {
        tab.empty();
        tab.append("用户名不能为空");
        return;
    }
    if (password == "") {
        tab.empty();
        tab.append("密码不能为空");
        return;
    }
    if (pwd == "") {
        tab.empty();
        tab.append("确认密码不能为空");
        return;
    }
    if (password != pwd) {
        tab.empty();
        tab.append("密码和确认密码不一致");
        return;
    }
    if (age == "") {
        tab.empty();
        tab.append("年龄不能为空");
        return;
    }
    if (isNaN(age)) {
        tab.empty();
        tab.append("年龄必须是数字");
        return;
    }
    if (phone == "") {
        tab.empty();
        tab.append("电话号码不能为空");
        return;
    }
    var sex = "";
    if (gender == "女") {
        sex = 0;
    }
    if (gender == "男") {
        sex = 1;
    }
    window.alert(sex);
    var data = {
        "username":username,
        "password":password,
        "age":age,
        "sex": sex,
        "phone":phone
    };
    var jsondata = JSON.stringify(data);
    $.ajax({
        type: "post",
        url: "/user/userAdd",
        data: jsondata,
        contentType: "application/json;",
        success: function (r) {
            if(r.resultCode == 200) {
                window.location.href = "../views/index.html";
            }
        },error:function (r) {
            if(r.resultCode == 500){
                tab.empty();
                tab.append("注册失败");
                return;
            }
        }
    });
}

// function das(){
// 	var sex = $('input[name=sex]:checked').val();
// 	var male;
// 	if(sex == "男"){
// 	    male = 1;
//         window.alert(male);
//     }
// 	if(sex == "女"){
// 	    male = 0;
//         window.alert(male);
//     }
// }

// <!--$("#dada").click(function () {
//     $.ajax({
//         type:'',
//         data:'',
//         success:function () {
//             window.location.href="login.html";
//         }
//     })
//
// })-->
